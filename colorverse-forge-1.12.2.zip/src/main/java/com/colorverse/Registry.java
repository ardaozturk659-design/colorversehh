package com.colorverse;

import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.registry.EntityEntry;
import net.minecraftforge.fml.common.registry.EntityEntryBuilder;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = ColorVerse.MODID)
public class Registry {
    public static final ColorPortalBlock[] PORTALS = new ColorPortalBlock[16];

    static {
        for (int i = 0; i < 16; i++) PORTALS[i] = new ColorPortalBlock(i);
    }

    @SubscribeEvent
    public static void registerBlocks(RegistryEvent.Register<Block> e) {
        e.getRegistry().registerAll(PORTALS);
    }

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> e) {
        for (ColorPortalBlock b : PORTALS) {
            ItemBlock ib = new ItemBlock(b);
            ib.setRegistryName(b.getRegistryName());
            e.getRegistry().register(ib);
        }
    }

    @SubscribeEvent
    public static void registerEntities(RegistryEvent.Register<EntityEntry> e) {
        e.getRegistry().register(EntityEntryBuilder.create()
                .entity(EntityNpc.class)
                .id(new ResourceLocation(ColorVerse.MODID, "npc"), 0)
                .name("npc")
                .tracker(64, 3, true)
                .egg(0x111111, 0xFFFFFF)
                .build());
    }
}
