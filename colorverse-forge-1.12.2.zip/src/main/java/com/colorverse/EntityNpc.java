package com.colorverse;

import java.util.UUID;

import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIAttackMelee;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.inventory.InventoryBasic;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.pathfinding.PathNavigateGround;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.NonNullList;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.block.state.IBlockState;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.World;

public class EntityNpc extends EntityCreature {
    public static final String NAME = "darklord5456";
    public enum Mode { IDLE, FOLLOW, STAY, FIGHT, WOOD, STONE, COLLECT, THUNDER }

    private Mode mode = Mode.IDLE;
    private UUID commander;
    private int noPickup;
    public final InventoryBasic inventory = new InventoryBasic("Bot", false, 27);

    public EntityNpc(World world) {
        super(world);
        setSize(0.6F, 1.8F);
        enablePersistence();
        setCustomNameTag(NAME);
        setAlwaysRenderNameTag(true);
        setDropChance(EntityEquipmentSlot.MAINHAND, 0.0F);
        ((PathNavigateGround) getNavigator()).setCanSwim(true);
        updateHeldItem();
    }

    @Override
    protected void initEntityAI() {
        tasks.addTask(0, new EntityAISwimming(this));
        tasks.addTask(1, new EntityAIAttackMelee(this, 1.2D, true));
        tasks.addTask(2, new EntityAIWork(this));
        tasks.addTask(3, new EntityAIFollowCommander(this));
        tasks.addTask(5, new EntityAIWander(this, 0.8D) {
            @Override
            public boolean shouldExecute() {
                return EntityNpc.this.getMode() == Mode.IDLE && super.shouldExecute();
            }
        });
        tasks.addTask(6, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
        tasks.addTask(7, new EntityAILookIdle(this));
        targetTasks.addTask(1, new EntityAINearestAttackableTarget<EntityMob>(this, EntityMob.class, 10, true, false,
                new com.google.common.base.Predicate<EntityMob>() {
                    @Override
                    public boolean apply(EntityMob e) {
                        return EntityNpc.this.getMode() == Mode.FIGHT;
                    }
                }));
    }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(40.0D); // 20 kalp
        getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.3D);
        getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(32.0D);
        getAttributeMap().registerAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(7.0D);
    }

    public Mode getMode() { return mode; }

    public void setMode(Mode m, EntityPlayer by) {
        this.mode = m;
        if (by != null) this.commander = by.getUniqueID();
        setAttackTarget(null);
        getNavigator().clearPath();
        updateHeldItem();
    }

    public EntityPlayer getCommander() {
        return commander == null ? null : world.getPlayerEntityByUUID(commander);
    }

    public void teleportNear(EntityPlayer p) {
        setLocationAndAngles(p.posX + 1.0D, p.posY, p.posZ + 1.0D, rotationYaw, rotationPitch);
        getNavigator().clearPath();
    }

    private void updateHeldItem() {
        ItemStack s;
        if (mode == Mode.WOOD) s = new ItemStack(Items.IRON_AXE);
        else if (mode == Mode.STONE) s = new ItemStack(Items.IRON_PICKAXE);
        else if (mode == Mode.THUNDER) s = new ItemStack(Items.BLAZE_ROD);
        else s = new ItemStack(Items.IRON_SWORD);
        setItemStackToSlot(EntityEquipmentSlot.MAINHAND, s);
    }


    // Electroblob's Wizardry: /cast <buyu> <x> <y> <z> <yon> komutunu Bot'un konumundan calistirir
    public boolean castSpell(String spell, EntityPlayer by) {
        MinecraftServer server = world.getMinecraftServer();
        if (world.isRemote || server == null) return false;
        EntityMob best = null;
        double bd = Double.MAX_VALUE;
        for (EntityMob m : world.getEntitiesWithinAABB(EntityMob.class, getEntityBoundingBox().grow(24.0D))) {
            if (!m.isEntityAlive()) continue;
            double d = getDistanceSq(m);
            if (d < bd) { bd = d; best = m; }
        }
        double bx = posX, by0 = posY + 1.5D, bz = posZ;
        double x = bx, y = by0, z = bz;
        EnumFacing dir;
        if (best != null) {
            double tx = best.posX, ty = best.posY + best.height / 2.0D, tz = best.posZ;
            // zombinin en cok uzak oldugu eksene gore yon sec (yukari, asagi, kuzey...)
            dir = EnumFacing.getFacingFromVector((float) (tx - bx), (float) (ty - by0), (float) (tz - bz));
            // buyunun duz cizgisi zombiden gececek sekilde baslangic noktasini kaydir
            switch (dir.getAxis()) {
                case X: y = ty; z = tz; break;
                case Y: x = tx; z = tz; break;
                default: x = tx; y = ty; break;
            }
            if (world.getBlockState(new BlockPos(x, y, z)).getMaterial().blocksMovement()) {
                x = bx; y = by0; z = bz; // blok icindeyse Bot'un konumundan at
            }
            getLookHelper().setLookPositionWithEntity(best, 30.0F, 30.0F);
        } else {
            dir = by.getHorizontalFacing();
        }
        swingArm(EnumHand.MAIN_HAND);
        String cmd = String.format(java.util.Locale.ROOT, "cast %s %.2f %.2f %.2f %s", spell, x, y, z, dir.getName());
        return server.getCommandManager().executeCommand(server, cmd) > 0;
    }

    // ---- envanter ----
    public void addToInventory(ItemStack stack) {
        ItemStack rest = inventory.addItem(stack);
        if (!rest.isEmpty()) entityDropItem(rest, 0.0F);
    }

    public int giveItemsTo(EntityPlayer p) {
        int n = 0;
        for (int i = 0; i < inventory.getSizeInventory(); i++) {
            ItemStack s = inventory.getStackInSlot(i);
            if (!s.isEmpty()) {
                n += s.getCount();
                world.spawnEntity(new EntityItem(world, p.posX, p.posY + 0.5D, p.posZ, s.copy()));
                inventory.setInventorySlotContents(i, ItemStack.EMPTY);
            }
        }
        if (n > 0) noPickup = 80;
        return n;
    }

    // blok kir ve esyalari envantere al
    public void harvest(BlockPos pos) {
        IBlockState s = world.getBlockState(pos);
        NonNullList<ItemStack> drops = NonNullList.create();
        s.getBlock().getDrops(drops, world, pos, s, 0);
        world.destroyBlock(pos, false);
        for (ItemStack d : drops) addToInventory(d);
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        if (world.isRemote) return;
        if (noPickup > 0) noPickup--;
        if (!isEntityAlive()) return;
        if (ticksExisted % 40 == 0) heal(1.0F);
        if (mode == Mode.THUNDER && ticksExisted % 30 == 0) {
            EntityPlayer c = getCommander();
            EntityMob best = null;
            double bd = Double.MAX_VALUE;
            for (EntityMob m : world.getEntitiesWithinAABB(EntityMob.class, getEntityBoundingBox().grow(24.0D))) {
                if (!m.isEntityAlive()) continue;
                if (c != null && m.getDistanceSq(c) < 16.0D) continue;
                double d = getDistanceSq(m);
                if (d < 9.0D) continue;
                if (d < bd) { bd = d; best = m; }
            }
            if (best != null) {
                swingArm(EnumHand.MAIN_HAND);
                world.addWeatherEffect(new EntityLightningBolt(world, best.posX, best.posY, best.posZ, false));
            }
        }
        EntityLivingBase t = getAttackTarget();
        if (t != null && (t.isDead || getDistanceSq(t) > 900.0D)) setAttackTarget(null);
        if (noPickup == 0 && ticksExisted % 5 == 0) {
            for (EntityItem it : world.getEntitiesWithinAABB(EntityItem.class, getEntityBoundingBox().grow(1.2D, 0.5D, 1.2D))) {
                if (it.isDead || it.getItem().isEmpty()) continue;
                ItemStack rest = inventory.addItem(it.getItem().copy());
                if (rest.isEmpty()) it.setDead();
                else it.setItem(rest);
            }
        }
    }

    @Override
    public boolean attackEntityAsMob(net.minecraft.entity.Entity target) {
        float dmg = (float) getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).getAttributeValue();
        boolean hit = target.attackEntityFrom(DamageSource.causeMobDamage(this), dmg);
        if (hit) swingArm(EnumHand.MAIN_HAND);
        return hit;
    }

    @Override
    public boolean attackEntityFrom(DamageSource source, float amount) {
        boolean r = super.attackEntityFrom(source, amount);
        if (r && !world.isRemote && source.getTrueSource() instanceof EntityLiving
                && !(source.getTrueSource() instanceof EntityPlayer)) {
            setAttackTarget((EntityLivingBase) source.getTrueSource());
        }
        return r;
    }

    @Override
    public void onDeath(DamageSource cause) {
        if (!world.isRemote) InventoryHelper.dropInventoryItems(world, this, inventory);
        super.onDeath(cause);
    }

    @Override
    public boolean processInteract(EntityPlayer player, EnumHand hand) {
        if (hand != EnumHand.MAIN_HAND) return false;
        if (!world.isRemote) {
            commander = player.getUniqueID();
            int given = giveItemsTo(player);
            String msg = given > 0 ? "Sana " + given + " esya verdim."
                    : "Merhaba! Ornek: " + NAME + " gel | dur | saldir | odun | tas | topla | yildirim | ver";
            player.sendMessage(new TextComponentString("\u00a7e[" + NAME + "] \u00a7f" + msg + " \u00a77(Can: "
                    + (int) getHealth() + "/" + (int) getMaxHealth() + ")"));
        }
        return true;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource s) { return SoundEvents.ENTITY_PLAYER_HURT; }

    @Override
    protected SoundEvent getDeathSound() { return SoundEvents.ENTITY_PLAYER_DEATH; }

    @Override
    public void writeEntityToNBT(NBTTagCompound c) {
        super.writeEntityToNBT(c);
        c.setInteger("NpcMode", mode.ordinal());
        if (commander != null) c.setUniqueId("NpcCommander", commander);
        NBTTagList list = new NBTTagList();
        for (int i = 0; i < inventory.getSizeInventory(); i++) {
            ItemStack s = inventory.getStackInSlot(i);
            if (!s.isEmpty()) {
                NBTTagCompound t = new NBTTagCompound();
                t.setByte("Slot", (byte) i);
                s.writeToNBT(t);
                list.appendTag(t);
            }
        }
        c.setTag("NpcInv", list);
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound c) {
        super.readEntityFromNBT(c);
        int m = c.getInteger("NpcMode");
        mode = (m >= 0 && m < Mode.values().length) ? Mode.values()[m] : Mode.IDLE;
        if (c.hasUniqueId("NpcCommander")) commander = c.getUniqueId("NpcCommander");
        NBTTagList list = c.getTagList("NpcInv", 10);
        for (int i = 0; i < list.tagCount(); i++) {
            NBTTagCompound t = list.getCompoundTagAt(i);
            int slot = t.getByte("Slot") & 255;
            if (slot < inventory.getSizeInventory()) inventory.setInventorySlotContents(slot, new ItemStack(t));
        }
        updateHeldItem();
        setCustomNameTag(NAME);
    }
}
