package com.colorverse;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import net.minecraft.block.BlockColored;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.init.Biomes;
import net.minecraft.init.Blocks;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkPrimer;
import net.minecraft.world.gen.IChunkGenerator;

public class ColorChunkGenerator implements IChunkGenerator {
    private final World world;
    private final IBlockState top;

    public ColorChunkGenerator(World world, int idx) {
        this.world = world;
        this.top = Blocks.WOOL.getDefaultState().withProperty(BlockColored.COLOR, EnumDyeColor.byMetadata(idx));
    }

    @Override
    public Chunk generateChunk(int cx, int cz) {
        ChunkPrimer pr = new ChunkPrimer();
        IBlockState stone = Blocks.STONE.getDefaultState();
        IBlockState bedrock = Blocks.BEDROCK.getDefaultState();
        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                pr.setBlockState(x, 0, z, bedrock);
                for (int y = 1; y <= 60; y++) pr.setBlockState(x, y, z, stone);
                for (int y = 61; y <= 63; y++) pr.setBlockState(x, y, z, top); // renkli yüzey
            }
        }
        Chunk chunk = new Chunk(world, pr, cx, cz);
        byte[] biomes = chunk.getBiomeArray();
        Arrays.fill(biomes, (byte) Biome.getIdForBiome(Biomes.PLAINS));
        chunk.generateSkylightMap();
        return chunk;
    }

    @Override public void populate(int x, int z) {}
    @Override public boolean generateStructures(Chunk chunk, int x, int z) { return false; }
    @Override public List<Biome.SpawnListEntry> getPossibleCreatures(EnumCreatureType type, BlockPos pos) { return Collections.emptyList(); }
    @Override public BlockPos getNearestStructurePos(World w, String name, BlockPos pos, boolean flag) { return null; }
    @Override public void recreateStructures(Chunk chunk, int x, int z) {}
    @Override public boolean isInsideStructure(World w, String name, BlockPos pos) { return false; }
}
