package com.colorverse;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import net.minecraft.block.Block;
import net.minecraft.block.BlockLog;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class EntityAIWork extends EntityAIBase {
    private final EntityNpc npc;
    private BlockPos target;
    private int progress, cooldown, stuck;
    private final Set<BlockPos> skip = new HashSet<BlockPos>();

    public EntityAIWork(EntityNpc npc) {
        this.npc = npc;
        setMutexBits(3);
    }

    private boolean active() {
        EntityNpc.Mode m = npc.getMode();
        return (m == EntityNpc.Mode.WOOD || m == EntityNpc.Mode.STONE || m == EntityNpc.Mode.COLLECT)
                && npc.getAttackTarget() == null;
    }

    @Override
    public boolean shouldExecute() { return active(); }

    @Override
    public boolean shouldContinueExecuting() { return active(); }

    @Override
    public void resetTask() {
        target = null;
        progress = 0;
        stuck = 0;
        skip.clear();
        npc.getNavigator().clearPath();
    }

    private boolean matches(IBlockState s, EntityNpc.Mode m) {
        Block b = s.getBlock();
        if (m == EntityNpc.Mode.WOOD) return b instanceof BlockLog;
        if (m == EntityNpc.Mode.STONE) return b == Blocks.STONE || b == Blocks.COAL_ORE || b == Blocks.IRON_ORE;
        return false;
    }

    private BlockPos findBlock(EntityNpc.Mode m) {
        World w = npc.world;
        BlockPos base = npc.getPosition();
        BlockPos best = null;
        double bd = Double.MAX_VALUE;
        for (int dx = -12; dx <= 12; dx++) {
            for (int dy = -5; dy <= 8; dy++) {
                for (int dz = -12; dz <= 12; dz++) {
                    BlockPos p = base.add(dx, dy, dz);
                    if (skip.contains(p) || !w.isBlockLoaded(p)) continue;
                    if (!matches(w.getBlockState(p), m)) continue;
                    double d = p.distanceSq(base);
                    if (d < bd) { bd = d; best = p; }
                }
            }
        }
        return best;
    }

    @Override
    public void updateTask() {
        EntityNpc.Mode m = npc.getMode();
        World w = npc.world;

        if (m == EntityNpc.Mode.COLLECT) {
            if (--cooldown > 0) return;
            cooldown = 20;
            List<EntityItem> items = w.getEntitiesWithinAABB(EntityItem.class, npc.getEntityBoundingBox().grow(16.0D, 6.0D, 16.0D));
            EntityItem best = null;
            double bd = Double.MAX_VALUE;
            for (EntityItem it : items) {
                if (it.isDead) continue;
                double d = npc.getDistanceSq(it);
                if (d < bd) { bd = d; best = it; }
            }
            if (best != null) npc.getNavigator().tryMoveToXYZ(best.posX, best.posY, best.posZ, 1.2D);
            return;
        }

        if (target != null && !matches(w.getBlockState(target), m)) {
            target = null;
            progress = 0;
        }
        if (target == null) {
            if (--cooldown > 0) return;
            cooldown = 20;
            target = findBlock(m);
            progress = 0;
            stuck = 0;
            return;
        }

        double x = target.getX() + 0.5D, y = target.getY() + 0.5D, z = target.getZ() + 0.5D;
        if (npc.getDistanceSq(x, y, z) > 16.0D) {
            if (npc.ticksExisted % 10 == 0) {
                npc.getNavigator().tryMoveToXYZ(x, target.getY(), z, 1.1D);
                stuck += npc.getNavigator().noPath() ? 5 : 1;
            }
            if (stuck > 25) {
                skip.add(target);
                target = null;
            }
            return;
        }

        npc.getNavigator().clearPath();
        npc.getLookHelper().setLookPosition(x, y, z, 30.0F, 30.0F);
        IBlockState s = w.getBlockState(target);
        int need = Math.max(8, (int) (s.getBlockHardness(w, target) * 15.0F));
        if (progress % 6 == 0) npc.swingArm(EnumHand.MAIN_HAND);
        if (++progress >= need) {
            npc.harvest(target);
            target = null;
            progress = 0;
            stuck = 0;
        }
    }
}
