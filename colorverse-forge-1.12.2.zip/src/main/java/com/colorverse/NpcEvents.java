package com.colorverse;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = ColorVerse.MODID)
public class NpcEvents {
    private static final String PREFIX = "\u00a7e[" + EntityNpc.NAME + "] \u00a7f";

    private static boolean has(String[] words, String... keys) {
        for (String w : words) for (String k : keys) if (w.startsWith(k)) return true;
        return false;
    }

    @SubscribeEvent
    public static void onChat(ServerChatEvent event) {
        EntityPlayerMP p = event.getPlayer();
        String msg = event.getMessage().trim();

        // "darklord5456 gel" gibi isimle cagirma: yuklu alandaki her yerden duyar
        boolean named = false;
        if (msg.toLowerCase(Locale.ROOT).startsWith(EntityNpc.NAME)) {
            named = true;
            msg = msg.substring(EntityNpc.NAME.length()).replaceFirst("^[\\s,:;!.]+", "");
            if (msg.isEmpty()) msg = "gel";
        }

        List<EntityNpc> npcs = new ArrayList<EntityNpc>();
        if (named) {
            for (Entity e : p.world.loadedEntityList) if (e instanceof EntityNpc) npcs.add((EntityNpc) e);
        } else {
            npcs.addAll(p.world.getEntitiesWithinAABB(EntityNpc.class, p.getEntityBoundingBox().grow(48.0D)));
        }
        if (npcs.isEmpty()) {
            if (named) p.sendMessage(new TextComponentString(PREFIX + "Bu bolgede degilim, yuklu alanda olmam lazim."));
            return;
        }

        // Wizardry buyusu: "cast ebwizardry:fireball" veya "buyu fireball"
        String[] raw = msg.toLowerCase(Locale.ROOT).split("\\s+");
        if (raw.length >= 2 && (raw[0].equals("cast") || raw[0].equals("b\u00fcy\u00fc") || raw[0].equals("buyu"))) {
            String spell = raw[1];
            if (!spell.matches("[a-z0-9_:]+")) return;
            if (spell.indexOf(':') < 0) spell = "ebwizardry:" + spell;
            for (EntityNpc npc : npcs) {
                boolean ok = npc.castSpell(spell, p);
                p.sendMessage(new TextComponentString(PREFIX
                        + (ok ? spell + " buyusunu attim!" : "Buyu calismadi (Wizardry yuklu mu, adi dogru mu?)")));
            }
            return;
        }

        String[] w = msg.toLowerCase(new Locale("tr", "TR")).split("[^\\p{L}]+");
        EntityNpc.Mode mode;
        String reply;
        boolean give = false;

        if (has(w, "y\u0131ld\u0131r", "yildir", "\u015fim\u015fek", "simsek")) { mode = EntityNpc.Mode.THUNDER; reply = "Yildirim yagdiriyorum!"; }
        else if (has(w, "gel", "takip", "yan\u0131ma", "yanima")) { mode = EntityNpc.Mode.FOLLOW; reply = "Geliyorum!"; }
        else if (has(w, "dur", "bekle")) { mode = EntityNpc.Mode.STAY; reply = "Tamam, burada bekliyorum."; }
        else if (has(w, "sald\u0131r", "saldir", "vur", "sava\u015f", "savas", "koru")) { mode = EntityNpc.Mode.FIGHT; reply = "Canavarlara saldiriyorum!"; }
        else if (has(w, "odun", "a\u011fa\u00e7", "agac", "kes")) { mode = EntityNpc.Mode.WOOD; reply = "Odun topluyorum."; }
        else if (has(w, "ta\u015f", "tas", "kaz", "maden")) { mode = EntityNpc.Mode.STONE; reply = "Tas kaziyorum."; }
        else if (has(w, "topla", "e\u015fya", "esya")) { mode = EntityNpc.Mode.COLLECT; reply = "Yerdeki esyalari topluyorum."; }
        else if (has(w, "ver", "getir")) { mode = null; reply = null; give = true; }
        else {
            if (named) p.sendMessage(new TextComponentString(PREFIX
                    + "Anlamadim. Ornek: " + EntityNpc.NAME + " gel / dur / saldir / odun / tas / topla / yildirim / ver / cast ebwizardry:fireball"));
            return;
        }

        for (EntityNpc npc : npcs) {
            String text = reply;
            if (give) {
                int n = npc.giveItemsTo(p);
                text = n > 0 ? "Sana " + n + " esya verdim." : "Envanterim bos.";
            } else {
                npc.setMode(mode, p);
            }
            p.sendMessage(new TextComponentString(PREFIX + text));
        }
    }
}
