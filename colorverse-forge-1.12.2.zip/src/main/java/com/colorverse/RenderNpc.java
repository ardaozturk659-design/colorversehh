package com.colorverse;

import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.layers.LayerHeldItem;
import net.minecraft.util.ResourceLocation;

public class RenderNpc extends RenderLiving<EntityNpc> {
    private static final ResourceLocation TEX = new ResourceLocation(ColorVerse.MODID, "textures/entity/npc.png");

    public RenderNpc(RenderManager manager) {
        super(manager, new ModelPlayer(0.0F, false), 0.5F);
        addLayer(new LayerHeldItem(this));
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityNpc entity) { return TEX; }
}
