KURULUM (Forge 1.12.2 MDK ile)
1) Forge 1.12.2 MDK'yi indir ve ac.
2) Bu zipteki src/main klasorunun icindekileri MDK'nin src/main klasorune kopyala.
3) gradlew build -> build/libs icinde .jar cikar, mods klasorune at.
   (test icin: gradlew runClient)

KULLANIM
- Yaratici modda "Insaat Bloklari" sekmesinde 16 renkli Portal blogu var.
- Portal blogunun ustune bas -> o rengin evrenine isinlanirsin (ID 100-115).
- Evrende (3,63,0) konumunda geri donus portali olusur; ustune basinca overworld'e donersin.
- Komutla gecis: /forge tpx 100 (beyaz) ... 115 (siyah)

NPC (BOT)
- Yaratici modda Cesitli (Misc) sekmesinde "Bot" spawn yumurtasi var. Yere tikla, Bot gelir.
- Sohbete yaz (yakinindaysa duyar):
  gel -> seni takip eder | dur -> bekler | saldir/vur -> canavarlara saldirir
  yildirim -> uzaktaki canavarlara (zombi vb.) yildirim dusurur
  odun -> agac keser | tas -> tas, komur, demir kazar | topla -> yerdeki esyalari toplar
  ver -> topladiklarini sana verir (ya da ona sag tikla)
- Cani 40 (20 kalp), yavas yavas iyilesir. Olursa esyalarini birakir.
- Skin: src/main/resources/assets/colorverse/textures/entity/npc.png

WIZARDRY BUYUSU
- Sohbete "/" olmadan yaz:  cast ebwizardry:fireball   (veya:  buyu fireball)
- Bot en yakin canavara dogru (yoksa senin baktigin yone) Wizardry'nin /cast komutunu kendi konumundan calistirir.
- Electroblob's Wizardry yuklu olmali.

ISIMLE CAGIRMA
- Botun adi: darklord5456
- Sohbete yaz:  darklord5456 gel   /  darklord5456 dur  /  darklord5456 odun  /  darklord5456 cast ebwizardry:fireball
- Sadece "darklord5456" yazarsan sana gelir. Isimle yazinca, yuklu alanda neredeyse oradan duyar ve yanina isinlanir.
